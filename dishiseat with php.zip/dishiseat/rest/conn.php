<?php

$connect = new mysqli("localhost","root","","dishiseat");

if($connect){
	 
}else{
	echo "Connection Failed";
	exit();
}